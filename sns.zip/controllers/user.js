const User = require('../models/user');

exports.follow = async (req,res,next)=>{
    try{
        const user = await User.findOne({where: {id:req.user.id}});
        if(user){
            await user.addFollowing(parseInt(req.parmas.id,10));
            res.send('success');
        }else{
            res.staus(404).send('no user');
        }
    }catch(error){
        console.error(error);
        next(error);
    }
};